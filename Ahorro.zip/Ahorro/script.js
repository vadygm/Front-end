document.addEventListener('DOMContentLoaded', function() {
    const botones = document.querySelectorAll('.botones button');

    botones.forEach(function(boton) {
        boton.addEventListener('click', function() {
            switch (boton.textContent) {
                case 'Retirar':
                    retirar();
                    break;
                case 'Depositar':
                    depositar();
                    break;
                case 'Consultar Movimientos':
                    consultarMovimientos();
                    break;
            }
        });
    });
});

function retirar() {
    const saldo = parseInt(document.querySelector('.saldo p').textContent);
    const cantidad = parseInt(prompt('Ingrese la cantidad a retirar:'));

    if (cantidad <= saldo) {
        const nuevoSaldo = saldo - cantidad;
        document.querySelector('.saldo p').textContent = nuevoSaldo;
        alert('Retiro exitoso');
    } else {
        alert('No hay suficiente saldo para retirar esta cantidad');
    }
}

function depositar() {
    const saldo = parseInt(document.querySelector('.saldo p').textContent);
    const cantidad = parseInt(prompt('Ingrese la cantidad a depositar:'));

    const nuevoSaldo = saldo + cantidad;
    document.querySelector('.saldo p').textContent = nuevoSaldo;
    alert('Depósito exitoso');
}

function consultarMovimientos() {
    alert('Movimientos:\n- Retiro de $1000\n- Deposito de $5000');
}